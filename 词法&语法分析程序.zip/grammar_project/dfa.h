#include <map>
#include <iostream>
#include <cstdio>
#include <string>

using namespace std;

void solve();
void init();
void pr(string str);
void pr(char ch);
void f19_fun(char &ch,string &str);
void f20_fun(char &ch,string &str);
void input_comment(char &ch);
bool input(char &ch);
void output_delimiter();
